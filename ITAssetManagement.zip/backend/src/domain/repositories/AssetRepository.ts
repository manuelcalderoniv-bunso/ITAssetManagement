import { Asset } from "../entities/Asset";

export interface AssetRepository {
  save(asset: Asset): Promise<void>;

  findAll(): Promise<Asset[]>;
  
  findByTag(assetTag: string): Promise<Asset | null>;

  updateStatus(
  assetTag: string,
  status: string,
  updatedBy: string
): Promise<void>;

  delete(
    assetTag: string
  ): Promise<void>;

}