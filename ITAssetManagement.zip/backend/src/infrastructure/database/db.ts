import knex from "knex";
import dotenv from "dotenv";
dotenv.config();

export const db = knex({
  client: "mysql2",
  connection: {
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT) || 3306,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
  },
});

db.raw("SELECT 1")
  .then(() => console.log("MySQL Connected"))
  .catch((err) => console.error("MySQL Connection Error:", err));
