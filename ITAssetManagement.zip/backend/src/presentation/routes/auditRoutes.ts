import { Router } from "express";
import { authMiddleware } from "../middlewares/authMiddleware";
import { AuditController } from "../controllers/AuditController";
import { GetAssetHistory } from "../../application/services/GetAssetHistory";
import { GetUserHistory } from "../../application/services/GetUserHistory";

const router = Router();

const getAssetHistory =
  new GetAssetHistory();

const getUserHistory =
  new GetUserHistory();

const auditController =
  new AuditController(
    getAssetHistory,
    getUserHistory
  );

router.get(
  "/audit/assets/:tag",
  authMiddleware,
  (req, res) => {
    return auditController.getAssetHistory(
      req,
      res
    );
  }
);

router.get(
  "/audit/user/:email",
  authMiddleware,
  (req, res) => {
    return auditController.getUserHistory(
      req,
      res
    );
  }
);

export default router;