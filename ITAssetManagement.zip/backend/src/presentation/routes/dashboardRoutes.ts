import { Router } from "express";
import { DashboardController } from "../controllers/DashboardController";
import { GetDashboardStats } from "../../application/services/TempDashboardStats";
import { GetRecentActivities } from "../../application/services/GetRecentActivities";

const router = Router();

const dashboardController = new DashboardController(
  new GetDashboardStats(),
  new GetRecentActivities()
);

router.get("/stats", (req, res) => dashboardController.stats(req, res));
router.get("/recent-activities", (req, res) => dashboardController.recentActivities(req, res));

export default router;