import dashboardRoutes from "./routes/dashboardRoutes";
import auditRoutes from "./routes/auditRoutes";
import authRoutes from "./routes/authRoutes";
import swaggerUi from "swagger-ui-express";
import swaggerJSDoc from "swagger-jsdoc";
import assetRoutes from "./routes/assetRoutes";
import express from "express";
import cors from "cors";

const app = express();

import { Asset } from "../../domain/entities/Asset";
import { AssetRepository } from "../../domain/repositories/AssetRepository";
import { db } from "../database/db";

export class KnexAssetRepository implements AssetRepository {

  async findByTag(assetTag: string): Promise<Asset | null> {
    console.log("SEARCHING:", assetTag);
    console.log("TYPE:", typeof assetTag);
    
    const row = await db("assets")
      .where("asset_tag", assetTag)
      .first();

    console.log("ROW:", row);

    if (!row) {
      return null;
    }

  return new Asset({
    assetTag: row.asset_tag,
    assetType: row.asset_type,
    category: row.category,
    manufacturer: row.manufacturer,
    model: row.model,
    serialNumber: row.serial_number,
    status: row.status,
    createdBy: row.created_by,
    updatedBy: row.updated_by,
});

  }

  async save(asset: Asset): Promise<void> {

  await db("assets").insert({
    asset_tag: asset.data.assetTag,
    asset_type: asset.data.assetType,
    category: asset.data.category,
    manufacturer: asset.data.manufacturer,
    model: asset.data.model,
    serial_number: asset.data.serialNumber,
    status: asset.data.status,
    created_by: asset.data.createdBy ?? null,
    updated_by: asset.data.updatedBy ?? null,
  });

}

  async findAll(): Promise<Asset[]> {
    const rows = await db("assets").select("*");

    return rows.map(
       (row) =>
  new Asset({
    assetTag: row.asset_tag,
    assetType: row.asset_type,
    category: row.category,
    manufacturer: row.manufacturer,
    model: row.model,
    serialNumber: row.serial_number,
    status: row.status,
    createdBy: row.created_by,
    updatedBy: row.updated_by,
  })

);
  }
   async updateStatus(
  assetTag: string,
  status: string,
  updatedBy: string
): Promise<void> {

  console.log("UPDATED BY:", updatedBy);

  const result = await db("assets")
    .where("asset_tag", assetTag)
    .update({
      status,
      updated_by: updatedBy
    });

  console.log("ROWS UPDATED:", result);
}

  async delete(
    assetTag: string
  ): Promise<void> {
    await db("assets")
      .where("asset_tag", assetTag)
      .delete();

  }

}
app.use(express.json());

const swaggerSpec = swaggerJSDoc({
  definition: {
    openapi: "3.0.0",
    info: {
      title: "IT Asset Management API",
      version: "1.0.0",
      description: "API Documentation for IT Asset Management System",
    },
  },
  apis: ["./src/presentation/routes/*.ts"],
});

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use("/api", assetRoutes);
app.use("/api", authRoutes);
app.use("/api", auditRoutes);
app.use("/api", dashboardRoutes);

export default app;